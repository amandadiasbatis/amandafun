"use client"

import { useState } from "react"
import { ArrowLeft, ArrowRight, Award, Check, ChevronRight, CircleDot, CircleHelp, Lightbulb, Orbit, RotateCcw, Sparkles, Telescope, X } from "lucide-react"

type Category = "geral" | "ciencia" | "cultura"
type CategoryIcon = typeof CircleDot
type Question = { question: string; options: string[]; answer: number; note: string }

const questionSets: Record<Category, { label: string; icon: CategoryIcon; questions: Question[] }> = {
  geral: {
    label: "Planetas rochosos",
    icon: CircleDot,
    questions: [
      { question: "Qual é o menor planeta do Sistema Solar?", options: ["Marte", "Mercúrio", "Vênus", "Terra"], answer: 1, note: "Mercúrio é também o planeta mais próximo do Sol." },
      { question: "Qual planeta é conhecido como planeta vermelho?", options: ["Vênus", "Marte", "Júpiter", "Mercúrio"], answer: 1, note: "O óxido de ferro presente no solo dá a Marte sua aparência avermelhada." },
      { question: "Qual planeta tem uma atmosfera tão densa que retém muito calor?", options: ["Vênus", "Marte", "Mercúrio", "Terra"], answer: 0, note: "O intenso efeito estufa faz de Vênus o planeta mais quente do Sistema Solar." },
      { question: "Qual é o único planeta conhecido por abrigar vida?", options: ["Marte", "Vênus", "Terra", "Mercúrio"], answer: 2, note: "Até hoje, a Terra é o único mundo onde a vida foi confirmada." },
      { question: "Qual planeta tem o dia mais longo em relação ao seu ano?", options: ["Marte", "Terra", "Vênus", "Mercúrio"], answer: 2, note: "Vênus leva cerca de 243 dias terrestres para girar uma vez e 225 para orbitar o Sol." },
      { question: "Qual destes planetas não possui luas naturais?", options: ["Marte", "Terra", "Mercúrio", "Netuno"], answer: 2, note: "Mercúrio e Vênus são os únicos planetas sem luas." },
      { question: "Quantas luas conhecidas Marte tem?", options: ["Nenhuma", "Uma", "Duas", "Quatro"], answer: 2, note: "As pequenas luas de Marte se chamam Fobos e Deimos." },
      { question: "Qual planeta é o terceiro a partir do Sol?", options: ["Vênus", "Terra", "Marte", "Mercúrio"], answer: 1, note: "A ordem começa com Mercúrio, Vênus, Terra e Marte." },
    ],
  },
  ciencia: {
    label: "Gigantes gasosos e gelados",
    icon: Orbit,
    questions: [
      { question: "Qual é o maior planeta do Sistema Solar?", options: ["Saturno", "Netuno", "Júpiter", "Urano"], answer: 2, note: "Júpiter é tão grande que todos os outros planetas caberiam dentro dele." },
      { question: "Qual planeta é famoso por seus grandes anéis brilhantes?", options: ["Urano", "Saturno", "Netuno", "Júpiter"], answer: 1, note: "Os anéis de Saturno são feitos principalmente de gelo, poeira e fragmentos rochosos." },
      { question: "Qual planeta tem ventos que podem ultrapassar 2.000 km/h?", options: ["Júpiter", "Saturno", "Urano", "Netuno"], answer: 3, note: "Netuno tem alguns dos ventos mais velozes já registrados no Sistema Solar." },
      { question: "Que planeta gira quase de lado em relação ao plano de sua órbita?", options: ["Saturno", "Urano", "Júpiter", "Netuno"], answer: 1, note: "A inclinação extrema de Urano faz com que ele pareça rolar ao redor do Sol." },
      { question: "Qual destes planetas tem a Grande Mancha Vermelha?", options: ["Marte", "Júpiter", "Saturno", "Netuno"], answer: 1, note: "É uma tempestade gigantesca em Júpiter, observada há séculos." },
      { question: "Qual é o planeta mais distante do Sol?", options: ["Urano", "Saturno", "Netuno", "Júpiter"], answer: 2, note: "Netuno é o oitavo planeta, depois de Urano." },
      { question: "Qual gigante gasoso tem a menor densidade média?", options: ["Júpiter", "Saturno", "Urano", "Netuno"], answer: 1, note: "A densidade média de Saturno é menor que a da água." },
      { question: "Qual planeta tem uma cor azulada por causa do metano em sua atmosfera?", options: ["Vênus", "Marte", "Netuno", "Mercúrio"], answer: 2, note: "O metano absorve luz avermelhada e ajuda a dar a Netuno sua tonalidade azul." },
    ],
  },
  cultura: {
    label: "Explorando o Sistema Solar",
    icon: Telescope,
    questions: [
      { question: "Quantos planetas existem no Sistema Solar?", options: ["Sete", "Oito", "Nove", "Dez"], answer: 1, note: "A União Astronômica Internacional reconhece oito planetas." },
      { question: "Qual planeta fica entre a Terra e Júpiter?", options: ["Vênus", "Marte", "Saturno", "Mercúrio"], answer: 1, note: "A ordem é Terra, Marte e depois Júpiter." },
      { question: "Qual planeta completa uma volta ao redor do Sol mais rapidamente?", options: ["Vênus", "Mercúrio", "Marte", "Terra"], answer: 1, note: "Um ano em Mercúrio dura apenas 88 dias terrestres." },
      { question: "Qual destes corpos é classificado como planeta anão?", options: ["Europa", "Plutão", "Titã", "Fobos"], answer: 1, note: "Plutão foi reclassificado como planeta anão em 2006." },
      { question: "O que mantém os planetas em órbita ao redor do Sol?", options: ["Magnetismo", "Gravidade", "Vento solar", "Luz"], answer: 1, note: "A gravidade do Sol mantém os planetas em suas órbitas." },
      { question: "Qual planeta tem o maior número de luas confirmadas entre estas opções?", options: ["Terra", "Marte", "Júpiter", "Mercúrio"], answer: 2, note: "Júpiter tem dezenas de luas conhecidas, incluindo Ganimedes, a maior do Sistema Solar." },
      { question: "Qual é a estrela no centro do nosso Sistema Solar?", options: ["Sirius", "O Sol", "Polaris", "Vega"], answer: 1, note: "O Sol é uma estrela que fornece luz e energia aos planetas." },
      { question: "Qual sequência começa no planeta mais próximo do Sol?", options: ["Vênus, Terra, Mercúrio", "Mercúrio, Vênus, Terra", "Terra, Marte, Vênus", "Marte, Terra, Mercúrio"], answer: 1, note: "A sequência completa começa com Mercúrio, Vênus, Terra e Marte." },
    ],
  },
}

const letters = ["A", "B", "C", "D"]

function playCorrectTune() {
  const context = new window.AudioContext()
  const masterGain = context.createGain()
  const startAt = context.currentTime
  const notes = [523.25, 659.25, 783.99, 1046.5]

  masterGain.gain.setValueAtTime(0.22, startAt)
  masterGain.connect(context.destination)

  notes.forEach((frequency, index) => {
    const noteStart = startAt + index * 0.1
    const oscillator = context.createOscillator()
    const noteGain = context.createGain()

    oscillator.type = "sine"
    oscillator.frequency.setValueAtTime(frequency, noteStart)
    noteGain.gain.setValueAtTime(0.0001, noteStart)
    noteGain.gain.exponentialRampToValueAtTime(0.32, noteStart + 0.025)
    noteGain.gain.exponentialRampToValueAtTime(0.0001, noteStart + 0.28)
    oscillator.connect(noteGain)
    noteGain.connect(masterGain)
    oscillator.start(noteStart)
    oscillator.stop(noteStart + 0.29)

    if (index === notes.length - 1) {
      oscillator.addEventListener("ended", () => void context.close(), { once: true })
    }
  })
}

type Screen = "intro" | "playing" | "result"

export function QuizGame() {
  const [category, setCategory] = useState<Category>("geral")
  const [screen, setScreen] = useState<Screen>("intro")
  const [questionIndex, setQuestionIndex] = useState(0)
  const [selected, setSelected] = useState<number | null>(null)
  const [score, setScore] = useState(0)
  const currentSet = questionSets[category]
  const currentQuestion = currentSet.questions[questionIndex]
  const total = currentSet.questions.length

  function startQuiz() {
    setQuestionIndex(0)
    setSelected(null)
    setScore(0)
    setScreen("playing")
  }

  function chooseAnswer(index: number) {
    if (selected !== null) return
    setSelected(index)
    if (index === currentQuestion.answer) {
      setScore((value) => value + 1)
      playCorrectTune()
    }
  }

  function nextQuestion() {
    if (questionIndex + 1 === total) {
      setScreen("result")
      return
    }
    setQuestionIndex((value) => value + 1)
    setSelected(null)
  }

  const resultTitle = score === total ? "Incrível! Você gabaritou!" : score >= total * 0.65 ? "Mandou muito bem!" : score >= total * 0.35 ? "Boa! Você está no caminho." : "Que tal tentar de novo?"

  return (
    <main className="quiz-shell">
      <header className="topbar">
        <a className="brand" href="#inicio" onClick={(event) => { event.preventDefault(); setScreen("intro") }} aria-label="quizzmandy, página inicial">
          <span className="brand-mark"><CircleHelp size={22} strokeWidth={2.6} /></span>
          <span>quizzmandy<span className="brand-dot">.</span></span>
        </a>
        <div className="topbar-note"><span className="live-dot" /> um intervalo que vale a pena</div>
        <div className="topbar-tag">QUIZ DA VEZ <Sparkles size={14} /></div>
      </header>

      {screen === "intro" && (
        <section className="intro-layout" id="inicio" aria-labelledby="intro-title">
          <div className="intro-copy">
            <div className="eyebrow"><span className="eyebrow-line" /> CURIOSIDADE EM AÇÃO</div>
            <h1 id="intro-title">Uma viagem<br />pelo <span className="highlight-word">cosmos.</span></h1>
            <p className="intro-description">Oito perguntas sobre os planetas do nosso Sistema Solar. Escolha um percurso e descubra curiosidades a cada resposta.</p>
            <div className="feature-row">
              <div className="feature-item"><span className="feature-icon purple"><CircleHelp size={17} /></span><span><strong>8 perguntas</strong><small>por rodada</small></span></div>
              <span className="feature-divider" />
              <div className="feature-item"><span className="feature-icon yellow"><Award size={17} /></span><span><strong>Sem pressão</strong><small>no seu ritmo</small></span></div>
            </div>
          </div>
          <div className="start-card">
            <div className="card-topline"><span>ESCOLHA SEU TEMA</span><span className="card-count">01 — 03</span></div>
            <div className="category-list" role="group" aria-label="Temas do quiz">
              {(Object.entries(questionSets) as [Category, typeof questionSets[Category]][]).map(([key, value], index) => {
                const CategorySymbol = value.icon
                return <button key={key} className={`category-option ${category === key ? "selected" : ""}`} onClick={() => setCategory(key)} aria-pressed={category === key}>
                  <span className="category-emoji" aria-hidden="true"><CategorySymbol size={19} strokeWidth={1.8} /></span>
                  <span className="category-text"><strong>{value.label}</strong><small>8 perguntas · nível descontraído</small></span>
                  <span className="category-number">0{index + 1}</span>
                  <ChevronRight className="category-arrow" size={18} />
                </button>
              })}
            </div>
            <button className="start-button" onClick={startQuiz}>Começar o quiz <ArrowRight size={18} /></button>
            <p className="card-footnote">Sem cadastro. Só diversão e conhecimento.</p>
          </div>
          <div className="floating-note note-one"><span className="note-emoji"><Lightbulb size={18} /></span><span><strong>Aprender é divertido</strong><small>uma pergunta de cada vez</small></span></div>
          <div className="floating-note note-two"><Sparkles className="note-stars" size={17} /><span><strong>Curiosidade:</strong> você sabia?</span></div>
        </section>
      )}

      {screen === "playing" && (
        <section className="game-wrap" aria-labelledby="question-title">
          <div className="game-nav"><button className="back-button" onClick={() => setScreen("intro")}><ArrowLeft size={16} /> Sair do quiz</button><span className="game-category"><currentSet.icon size={14} aria-hidden="true" /> &nbsp;{currentSet.label}</span></div>
          <div className="game-card">
            <div className="game-progress-head"><span>PERGUNTA <strong>{String(questionIndex + 1).padStart(2, "0")}</strong><span className="progress-total"> / {String(total).padStart(2, "0")}</span></span><span className="score-pill"><Award size={15} /> {score} {score === 1 ? "ponto" : "pontos"}</span></div>
            <div className="progress-track" role="progressbar" aria-label="Progresso do quiz" aria-valuenow={questionIndex + 1} aria-valuemin={0} aria-valuemax={total}><span style={{ width: `${((questionIndex + 1) / total) * 100}%` }} /></div>
            <h2 className="question-title" id="question-title">{currentQuestion.question}</h2>
            <div className="answer-list" role="group" aria-label="Alternativas de resposta">
              {currentQuestion.options.map((option, index) => {
                const isCorrect = selected !== null && index === currentQuestion.answer
                const isWrong = selected === index && index !== currentQuestion.answer
                return <button key={option} className={`answer-option ${isCorrect ? "correct" : ""} ${isWrong ? "wrong" : ""}`} onClick={() => chooseAnswer(index)} disabled={selected !== null} aria-pressed={selected === index}>
                  <span className="answer-letter">{letters[index]}</span><span className="answer-copy">{option}</span>{isCorrect && <Check className="answer-state" size={19} />}{isWrong && <X className="answer-state" size={19} />}
                </button>
              })}
            </div>
            <div className={`feedback ${selected !== null ? "visible" : ""}`} aria-live="polite" aria-atomic="true">
              {selected !== null && <><span className={`feedback-icon ${selected === currentQuestion.answer ? "feedback-good" : "feedback-try"}`}>{selected === currentQuestion.answer ? <Check size={17} /> : <X size={17} />}</span><span className="feedback-copy"><strong>{selected === currentQuestion.answer ? "Resposta certa!" : "Quase!"}</strong><small>{currentQuestion.note}</small></span></>}
            </div>
            <div className="game-footer"><span className="footer-hint">Escolha uma alternativa para continuar</span><button className="next-button" onClick={nextQuestion} disabled={selected === null}>{questionIndex + 1 === total ? "Ver resultado" : "Próxima pergunta"}<ArrowRight size={17} /></button></div>
          </div>
        </section>
      )}

      {screen === "result" && (
        <section className="result-wrap" aria-labelledby="result-title">
          <div className="result-card">
            <Sparkles className="result-decoration result-decoration-one" size={24} aria-hidden="true" /><Orbit className="result-decoration result-decoration-two" size={20} aria-hidden="true" />
            <div className="result-icon"><Award size={36} strokeWidth={1.8} /></div>
            <div className="eyebrow result-eyebrow"><span className="eyebrow-line" /> FIM DE JOGO <span className="eyebrow-line" /></div>
            <h1 id="result-title">{resultTitle}</h1>
            <p className="result-description">Você concluiu o tema <strong>{currentSet.label}</strong>. Cada rodada é uma chance de descobrir algo novo.</p>
            <div className="score-summary"><span className="score-big">{score}<span>/{total}</span></span><span className="score-caption">respostas<br />corretas</span><span className="score-separator" /><span className="score-percent">{Math.round((score / total) * 100)}<span>%</span><small>de aproveitamento</small></span></div>
            <div className="result-actions"><button className="start-button" onClick={startQuiz}><RotateCcw size={17} /> Jogar novamente</button><button className="secondary-button" onClick={() => setScreen("intro")}>Escolher outro tema <ArrowRight size={16} /></button></div>
          </div>
        </section>
      )}

      <footer className="site-footer"><span className="footer-credit">feito para mentes curiosas <Sparkles className="footer-spark" size={11} aria-hidden="true" /></span><span>quizzmandy<span className="brand-dot">.</span> &copy; 2026</span></footer>
    </main>
  )
}
